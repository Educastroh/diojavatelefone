package telefonedio;

public class Navegador {
    public void exibirPagina(){
        pesquisarPagina();
        System.out.println("Exibindo pagina.");
    }

    private void pesquisarPagina(){
        System.out.println("Pesquisando pagina.");
    }

    public void atualizarPagina(){
        recarregarPagina();
        System.out.println("Pagina atualizada.");
    }

    private void recarregarPagina(){
        System.out.println("Recarregando pagina.");
    }

    public void adicinarAba(){
        System.out.println("Aba nova adicionada.");
    }
}
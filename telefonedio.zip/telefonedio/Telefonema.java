package telefonedio;

public class Telefonema {
    public void ligar(){
        discarNumero();
        System.out.println("Ligando.");
        conectarOutroTelefone();
    }

    public void atender(){
        conectarOutroTelefone();
        System.out.println("Atendendo telefonema.");
    }

    public void iniciarCorreioDeVoz(){
        System.out.println("Gravando correio de voz");
    }

    public void discarNumero(){
        System.out.println("Discando numero.");
    }

    private void conectarOutroTelefone(){
        System.out.println("conectando a outro telefone.");
    }
}

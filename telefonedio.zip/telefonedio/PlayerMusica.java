package telefonedio;

public class PlayerMusica{
    public void iniciarMusica(){
        conectarInternet();
        System.out.println("Tocando Musica.");
    }

    private void conectarInternet(){
        System.out.println("Conectando a internet");
    }

    public void pausarMusica(){
        System.out.println("Musica pausada.");
    }

    public void pesquisarMusica(){
        conectarInternet();
        System.out.println("Pesquisando musica.");
    }
}
